package com.spring.SpringCoreDemo;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class LifeCycleBean implements BeanNameAware, InitializingBean, DisposableBean {
	private String title;
	
	public LifeCycleBean() {
		System.out.println("LifeCycleBean constructor called");
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		System.out.println("Inside setTitle: " + title);
		this.title = title;
	}

	@Override
	public String toString() {
		return "LifeCycleBean [title=" + title + "]";
	}

	@Override
	public void setBeanName(String name) {
		System.out.println("Inside BeanNameAware - setBeanName: " + name);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Inside afterPropertiesSet().. ");
	}
	public void myBeanInit() {
		System.out.println("Inside myBeanInit()");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("Inside destroy()");
	}
	public void myBeanDestroy() {
		System.out.println("Inside myBeanDestroy()");
	}
}
