package com.spring.SpringCoreDemo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	//Initialize your IoC container
    	AbstractApplicationContext iocContainer = 
    			//new ClassPathXmlApplicationContext("Beans_simple.xml");
    			new FileSystemXmlApplicationContext("D:\\Training\\Ongoing_trainings\\Microservices_14_half_days_18_May_2021\\DAY-2\\shared_code\\SpringCoreDemo\\src\\main\\resources\\Beans_simple.xml");
    	
    	Order order = (Order)iocContainer.getBean("orderBean");
    	System.out.println("Order bean - " + order);
    	/*
    	LifeCycleBean lifeCycleBean = 
    			(LifeCycleBean)iocContainer.getBean("lifeCycleBean");
    	System.out.println("Message from bean: " + lifeCycleBean.getTitle());
    	*/
    	iocContainer.registerShutdownHook();
    }
}
