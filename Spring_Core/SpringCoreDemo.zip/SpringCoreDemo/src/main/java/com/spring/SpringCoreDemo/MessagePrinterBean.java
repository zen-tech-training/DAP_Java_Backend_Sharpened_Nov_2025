package com.spring.SpringCoreDemo;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class MessagePrinterBean implements BeanNameAware, ApplicationContextAware {
	private String message;

	public MessagePrinterBean() {
		super();
		System.out.println("Inside constructor");
	}

	public MessagePrinterBean(String message) {
		System.out.println("Inside parameterized constructor");
		this.message = message;
	}

	public void myBeanInit() {
		System.out.println("Inside myBeanInit()");
	}
	public void myBeanDestroy() {
		System.out.println("Inside myBeanDestroy()");
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
		System.out.println("setMessage(): " + this.message);
	}

	@Override
	public String toString() {
		return "MessagePrinterBean [message=" + message + "]";
	}

	@Override
	public void setBeanName(String name) {
		System.out.println("Bean name is: " + name);
		
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		System.out.println("My IoC container - " + applicationContext.getDisplayName());
		
	}
	
}
